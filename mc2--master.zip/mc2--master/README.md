# [Big Brain Time - Study Room](http://bbtstudyroom.ddns.net:3000)
## Tvz MC^2 2021

Our goal is to make online studying experience easier. With video calls and threads we want to encourage students to study and solve their problems together!
 
Requirement:
* Apache Maven
* JDK
* Node.js & npm

Install instructions:
* On whole project: mvn clean install
* In folder src/main/reactjs: npm install

Starting:
* Backend: src/main/java/BackendRun.java (Spring-boot)
* Frontend: src/main/reactjs (npm start)
