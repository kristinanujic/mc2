
import React, {useState} from 'react'
import axios from "axios";





const Comment = ({ comment }) => {



    return (
        <div></div>
    )
}

export default Comment