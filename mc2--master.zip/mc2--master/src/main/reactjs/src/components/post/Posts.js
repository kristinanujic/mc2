import React, {Component} from 'react'
import axios from "axios";
import {Link} from "react-router-dom";
import Post from './Post'

class Posts extends Component {
render(){
        return(
            <Post/>
    )
    }}

export default Posts;