import React, {Component} from 'react'
import Dashboard from './Dashboard'

class Dash extends Component {



    render() {
        return(
       <Dashboard/>
        );
    }
}

export default Dash;