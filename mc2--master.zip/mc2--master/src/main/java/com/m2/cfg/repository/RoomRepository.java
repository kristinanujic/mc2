package com.m2.cfg.repository;public interface RoomRepository {
}
