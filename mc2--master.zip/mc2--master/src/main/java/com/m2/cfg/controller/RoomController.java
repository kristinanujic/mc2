package com.m2.cfg.controller;public class RoomController {
}
